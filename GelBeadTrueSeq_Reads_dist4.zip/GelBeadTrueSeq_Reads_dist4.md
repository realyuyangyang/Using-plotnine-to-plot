```python
# To process data.
import pandas as pd
import numpy as np
# To plot.
from pylab import *
from plotnine import *
```


```python
# Loading data
dist4 = pd.read_table("barnyard01.split.txt___DF___SampleN_assigned_duplicates_dropped_dist4.tab")
dist4.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>read1_seq_n_mismatches</th>
      <th>hash_oligo_n_mismatches</th>
      <th>CellGelBeadBC_seq</th>
      <th>umi_seq</th>
      <th>hash_oligo_sample_barcode_seq</th>
      <th>GelBead_TrueSeq</th>
      <th>GelBead_Dist2True</th>
      <th>HashOligo_TrueSeq</th>
      <th>HashOligo_Dist2True</th>
      <th>SampleN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>9</td>
      <td>10</td>
      <td>AAAATTTCTTACGTTT</td>
      <td>CCTTTATTTT</td>
      <td>CAGCTAGCGG</td>
      <td>AAAATTTCTTACGTTT</td>
      <td>0.0</td>
      <td>CAGCTAGCGG</td>
      <td>0.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
      <td>AAACCGCCACACATGT</td>
      <td>TATGAAATTA</td>
      <td>GCGGCTGCGG</td>
      <td>AAACCGCCACACATGT</td>
      <td>0.0</td>
      <td>GCGGCTGCGG</td>
      <td>0.0</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7</td>
      <td>5</td>
      <td>AAACCGCCACACATGT</td>
      <td>TATGAAATTA</td>
      <td>GCGGCTGCGG</td>
      <td>AAACCGCCACACATGT</td>
      <td>0.0</td>
      <td>GCGGCTGCGG</td>
      <td>0.0</td>
      <td>9.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# To build df_gsr_drop
df_gsr = dist4.groupby(['GelBead_TrueSeq', 'SampleN'])['umi_seq'].count().reset_index(name = "Reads")
df_gsr_sort = df_gsr.sort_values(by=['Reads'],ascending=False)
df_gsr_drop = df_gsr_sort.drop_duplicates(['GelBead_TrueSeq'])#done
```


```python
df_gsr_drop.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GelBead_TrueSeq</th>
      <th>SampleN</th>
      <th>Reads</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5610</th>
      <td>ACGATACTCCCAGGTG</td>
      <td>10.0</td>
      <td>21162</td>
    </tr>
    <tr>
      <th>5918</th>
      <td>ACGCCAGGTCTGCGGT</td>
      <td>10.0</td>
      <td>17102</td>
    </tr>
    <tr>
      <th>706</th>
      <td>AAAGTAGGTTCTGTTT</td>
      <td>2.0</td>
      <td>9802</td>
    </tr>
    <tr>
      <th>6489</th>
      <td>ACGGCCATCGGGAGTA</td>
      <td>10.0</td>
      <td>9786</td>
    </tr>
    <tr>
      <th>5234</th>
      <td>ACCTTTAGTACCGTAT</td>
      <td>10.0</td>
      <td>9445</td>
    </tr>
  </tbody>
</table>
</div>




```python
# geom_point. Reorder GelBead_TrueSeq by Reads.
(ggplot(df_gsr_drop, aes(x = 'reorder(GelBead_TrueSeq,Reads)', y = 'log10(Reads)', color = 'factor(SampleN)' ) )
+ geom_point(aes(size = 'Reads'))
+ scale_alpha_continuous(range=(1,100))
+ labs(x='GelBead_TrueSeq', y='log10(Reads)', title = "GelBead_Reads_dist4")
+ theme_bw()
+ theme(panel_grid=element_blank(), axis_text_x = element_blank(), axis_ticks_major_x=element_blank())
)
```

    /home/yuyangyang/.local/lib/python3.8/site-packages/plotnine/guides/guides.py:197: PlotnineWarning: Cannot generate legend for the 'alpha' aesthetic. Make sure you have mapped a variable to it



    
![png](output_4_1.png)
    





    <ggplot: (8731453039330)>


